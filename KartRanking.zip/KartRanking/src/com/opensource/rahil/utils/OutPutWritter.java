package com.opensource.rahil.utils;

/**
 * This Class is responsible to print outputs this can be enhanced to print to file or anyother type of output device
 * As on @Date 24 March 2019 only supporting console printing
 * @author Mohamed Rahil Shaikh
 *
 */
public class OutPutWritter {
	public static void print(String messageToPrint) {
		if(Constants.isToPrintToConsole) {
			printToConsole(messageToPrint);
		}
	}
	private static void printToConsole(String messageToPrint) {
		System.out.println(messageToPrint);
	}
}
