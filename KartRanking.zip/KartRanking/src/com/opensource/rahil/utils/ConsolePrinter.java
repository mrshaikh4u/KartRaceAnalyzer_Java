package com.opensource.rahil.utils;

public class ConsolePrinter implements OutPutPrinter{
	
	public void print(String messageToPrint) {
		System.out.println(messageToPrint);
	}
}
