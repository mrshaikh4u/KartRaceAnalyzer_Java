package com.opensource.rahil.utils;


/**
 * This holds indexes for columns in input file
 * @author Mohamed Rahil Shaikh
 */
public enum INDEXES {
	START_TIME, PILOT_ID,HIPHEN, PILOT_NAME, LAP_NUM, LAP_TIME, VELOCITY
}
